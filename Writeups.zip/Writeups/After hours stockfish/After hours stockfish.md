## Question
The Grandmaster never needs to stay sober to destroy opposition!

**The Flag should be wrapped in aCTF{}**
![alt text](fen.gif)
## Approach
we had to search for the current world grandmaster magnus carlson's game,the game in which he livestreamed while he was drunk and check mated his opponent
and enter the moves in the chess notations

## Flag:
aCTF{Rxd8Kxd8Kd5g5e6g4Kd6g3e7#}
# Some instructions should be followed

## Question
Access the Website 's contents by obtaining the password from this file

**WEBSITE:** [https://protohype.pythonanywhere.com](https://protohype.pythonanywhere.com/)

## Note
The website should only allow numerical inputs


## Laws 
laws with their sections mentioned:

**Section 379**:It states that “whoever commits theft shall be punished with imprisonment of either description for a term which may extend to three years or with fine, or with both.”

**Section 411**: If a person receives any stolen property such as a computer, mobile phone, or data then he or she will be punished for three years or fine or both.

**Section 500**: It states that “Whoever defames another shall be punished with simple imprisonment for a term which may extend to two years, or with fine, or with both.”

**Section 469**:Whoever commits forgery,shall harm the reputation of any party, or knowing that it is likely to be used for that purpose, shall be punished with imprisonment of either description for a term which may extend to three years, and shall also be liable to fine

<hr>
we had to accumulate them and form the numbers which when inserted as password on the website to get the encoded flag
to get the prompt

```
Good Job! Your flag is djcj{mbbs_sludok_ki_sfxpegzng}
```
which gives the flag encoded by vigenere cipher where the key is the numbers converted to alphabets
 
## Numbers
    379411500469

## Flag:
actf{laws_should_be_respected}
# Welcome to Aurora
## Question
Do you dream of being Muhammad Ali? Cause this flag might just make you the people's champ...

**The Flag should be wrapped in aCTF{}**
## link
<a href="https://wearemist.in">link 1</a>

inside the team option on the website we had:
![alt text](image.png)

with 1st part present
then we had to go to the various socials present on the website to get the remaining 2 parts of the flag
![alt text](image-2.png)
![alt text](image-1.png)
## Flag
actf{FlaG_H1dd3n_1n_Pl4in_$igh7}

## divided in 3 parts:
1) actf{FlaG_
2) H1dd3n_1n_P
3) l4in_$igh7}